var myStudents = [
		{"firstName":"Suchismith","lastName":"Roy","CGPA":8.9},
		{"firstName":"Raghu","lastName":"Ram","CGPA":9.1},
		{"firstName":"Chhaya" ,"lastName":"Kashyap","CGPA":9.2},
		{"firstName":"Chhavi" ,"lastName":"Varma","CGPA":9.3},
		{"firstName":"ramneet","lastName":"singh","CGPA":9.23},
		{"firstName":"ritvik","lastName":"arora","CGPA":9.46},
		{"firstName":"parmjeet","lastName":"singh","CGPA":9.86}

]

var loopThroughData = function(students){
		for (x in students){
			if(students[x].firstName=='Raghu'){
      	alert("student found, cgpa is "+students[x].CGPA);
      }
      
		}
}
loopThroughData(myStudents);
